yes | pip3 install numpy transforms3d pyserial
yes | pip install numpy transforms3d pyserial

git clone https://github.com/stanfordroboticsclub/UDPComms.git
sudo bash UDPComms/install.sh