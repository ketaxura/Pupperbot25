#include <Arduino.h>
#include <BasicLinearAlgebra.h>
#include <CommandInterpreter.h>
#include <Streaming.h>

#include "DataLogger.h"
#include "DriveSystem.h"
#include "Utils.h"

////////////////////// CONFIG ///////////////////////
const int PRINT_DELAY = 10000;       // micros, 100hz
const int HEADER_DELAY = 5000;   // millis
const int CONTROL_DELAY = 1000;  // micros
const int IMU_DELAY = 5000; // micros
constexpr int IMU_FILTER_FREQUENCY = 1000000 / IMU_DELAY; // Hz
const float MAX_TORQUE = 0.5;
PDGains DEFAULT_GAINS = {8.0, 2.0};


bool start_motion = false;


const bool ECHO_COMMANDS = false;
////////////////////// END CONFIG ///////////////////////

DriveSystem drive;

const uint32_t kLogSize = 1000;
const uint32_t kNumAttributes = 1 + 6 + 7 * 12;
DataLogger<kLogSize, kNumAttributes> logger;

// Example json message with default start and stop characters: <{"kp":2.0}>
// use_msgpack: true, use default arguments for the rest
CommandInterpreter interpreter(true);
DrivePrintOptions options;

long last_command_ts;
long last_imu_ts;
long last_print_ts;
long last_header_ts;

bool print_debug_info = true;
bool print_header_periodically = false;

static bool hold = false;
static std::array<float,12> hold_pos;




static float theta_knee = 0.0f;
static float theta_shoulder = 0.0f;
static bool going_forward_knee = true;
static bool going_forward_shoulder = true;


// slow oscillation boundaries
const float MAX_ANGLE_knee = 2.0f;    // forward limit (~17 degrees)
// const float MIN_ANGLE = -0.5f;   // backward limit
const float MIN_ANGLE_knee = -0.1f;   // backward limit


const float MAX_ANGLE_shoulder = 1.0f;    // forward limit (~17 degrees)
const float MIN_ANGLE_shoulder = -0.1f;   // backward limit



bool homing_lock = true;

//drive lock to make sure the robot is commanded to move only after homing is finished.
bool drive_lock = true;
unsigned long drive_lock_time=0;


void printFloatFromBytes(uint8_t b0, uint8_t b1, uint8_t b2, uint8_t b3) {
  union { uint8_t b[4]; float f; } u;

  u.b[0] = b0;   // MsgPack uses big-endian floats
  u.b[1] = b1;
  u.b[2] = b2;
  u.b[3] = b3;

  Serial.print(u.f, 6);
}


void setup(void) {
  Serial.begin(500000);
  pinMode(13, OUTPUT);



  // Wait 1 second before turning on. This allows the motors to boot up.
  for (int i = 0; i < 20; i++) {
    digitalWrite(13, HIGH);
    delay(125);
    digitalWrite(13, LOW);
    delay(125);
  }


  //once the blinking is over, the rest of the setup block is executed. This blinking is a visual guide.


  //Setup the imu by giving it a frequency
  drive.SetupIMU(IMU_FILTER_FREQUENCY);



  //Every run time function has a set frequency. To achieve this frequency in code, we need to record an initial time.
  last_command_ts = micros();
  last_print_ts = micros();
  last_header_ts = millis();



  ////////////// Runtime config /////////////////////
  drive.SetMaxCurrent(MAX_TORQUE);
  options.delimiter = ',';
  options.print_delay_micros = PRINT_DELAY;
  options.header_delay_millis = HEADER_DELAY;
  options.positions = true;
  options.velocities = true;
  options.currents = false;             // last actual current
  options.position_references = false;  // last commanded position
  options.velocity_references = false;
  options.current_references = false;
  options.last_current = false;  // last commanded current

  // Set behavioral options
  drive.SetPositionKp(DEFAULT_GAINS.kp);
  drive.SetPositionKd(DEFAULT_GAINS.kd);
  drive.SetIdle();
  drive.PrintHeader(options);

  interpreter.Flush();

  // Activating the motors on bootup is dumb but it allows you to see debug
  // information
  // drive.SetActivations({1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1});
  // drive.SetActivations({1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});
  // drive.SetMaxCurrent(0.2);




  // FOR TESTING ONLY
  // drive.SetMaxCurrent(6.0);
  // drive.ZeroCurrentPosition();
  // drive.SetCartesianPositions(drive.DefaultCartesianPositions());
  // drive.SetCartesianKp3x3({5000.0, 0, 0, 0, 0.0, 0, 0, 0, 0.0});  //[A/m]
  // drive.SetCartesianKd3x3({75.0, 0, 0, 0, 0.0, 0, 0, 0, 0.0});  // [A /
  // (m/s)]

  drive.PrintHeader(options);

}



void loop() {


  //Setting up a command array to hold the position commands for all 12 motors
  std::array<float,12> cmd;

  // //Enforcing a max torque limit for safety
  // drive.SetMaxCurrent(4.0);
  // //Enforcing specific motor activations
  // drive.SetActivations({1,1,1,1,1,1,1,1,1,1,1,1});
  // // drive.SetActivations({1,1,1,0,0,0,0,0,0,0,0,0});


  //Check for any incoming CAN messages. Critical for ESC/Motor control.
  drive.CheckForCANMessages();


  // drive.CheckCANStability();

  // if (drive.CanStableFor5Sec()) {
  //   Serial.println("WHITE MONSTER");
  // }

  // drive.Update();


  //MUST DISABLE THIS IF YOU WANT TO USE THE TEENSY LOCALLY WITHOUT THE RPI
  //IF NOT DISABLED THE TEENSY WILL WAIT FOR COMMANDS FROM THE RPI AND NOT RUN ITS OWN MOTION CODE, AND HANG
  // //Check the serial buffer and receive data from the RPI.
  CheckResult r = interpreter.CheckForMessages();



// ==========================================================



  if (r.flag == CheckResultFlag::kNewCommand) {
    // Serial << "Got new command." << endl;


    // if (r.new_position) {
    //   drive.SetJointPositions(interpreter.LatestPositionCommand());
    //   if (ECHO_COMMANDS) {
    //     Serial << "Position command: " << interpreter.LatestPositionCommand()
    //            << endl;
    //   }
    // }
  
    if (r.new_position) {
        auto pos = interpreter.LatestPositionCommand();
        Serial.println("[TEENSY] New JOINT POSITION command received:");
        for (int i = 0; i < 12; i++) {
            Serial.print("J"); Serial.print(i);
            Serial.print(": ");
            Serial.println(pos[i], 4);
        }
        drive.SetJointPositions(pos);
    }




    // if (r.new_cartesian_position) {
    //   drive.SetCartesianPositions(interpreter.LatestCartesianPositionCommand());
    //   if (ECHO_COMMANDS) {
    //     Serial << "Cartesian position command: "
    //            << interpreter.LatestCartesianPositionCommand();
    //   }
    // }

    if (r.new_cartesian_position && drive_lock==false) {

      auto cart = interpreter.LatestCartesianPositionCommand();

      // Serial.println("[TEENSY] New CARTESIAN POSITION command received:");


      for (int leg = 0; leg < 4; leg++) {
          int idx = leg * 3;
          Serial.print("Leg ");
          Serial.print(leg);
          Serial.print(":  x=");
          Serial.print(cart[idx + 0], 4);
          Serial.print("  y=");
          Serial.print(cart[idx + 1], 4);
          Serial.print("  z=");
          Serial.println(cart[idx + 2], 4);
      }

      drive.SetCartesianPositions(cart);
  }



    if (r.new_kp) {
      drive.SetPositionKp(interpreter.LatestKp());
      if (ECHO_COMMANDS) {
        Serial << "Kp: " << interpreter.LatestKp() << endl;
      }
    }
    if (r.new_kd) {
      drive.SetPositionKd(interpreter.LatestKd());
      if (ECHO_COMMANDS) {
        Serial.print("Kd: ");
        Serial.println(interpreter.LatestKd(), 4);
      }
    }
    if (r.new_cartesian_kp) {
      drive.SetCartesianKp3x3(interpreter.LatestCartesianKp3x3());
      if (ECHO_COMMANDS) {
        Serial << "Cartesian Kp: " << interpreter.LatestCartesianKp3x3()
               << endl;
      }
    }
    if (r.new_cartesian_kd) {
      drive.SetCartesianKd3x3(interpreter.LatestCartesianKd3x3());
      if (ECHO_COMMANDS) {
        Serial << "Cartesian Kd: " << interpreter.LatestCartesianKd3x3()
               << endl;
      }
    }
    if (r.new_feedforward_force) {
      auto ff = interpreter.LatestFeedForwardForce();
      drive.SetFeedForwardForce(Utils::ArrayToVector<12, 12>(ff));
      if (ECHO_COMMANDS) {
      Serial << "Feed forward: " << interpreter.LatestFeedForwardForce()
             << endl;
      }
    }
    if (r.new_max_current) {
      drive.SetMaxCurrent(interpreter.LatestMaxCurrent());
      if (ECHO_COMMANDS) {
        Serial << "Max Current: " << interpreter.LatestMaxCurrent() << endl;
      }
    }

    // if (r.new_activation) {
    //   drive.SetActivations(interpreter.LatestActivations());
    //   if (ECHO_COMMANDS) {
    //     Serial << "Activations: " << interpreter.LatestActivations() << endl;
    //   }
    // }
    
    if (r.new_activation) {
      Serial.println("[TEENSY] Activation command received from RPi.");
      auto acts = interpreter.LatestActivations();

      Serial.print("Activations: ");
      for (int i = 0; i < 12; i++) {
          Serial.print(acts[i]);
          Serial.print(" ");
      }
      Serial.println();

      drive.SetActivations(acts);
    }



    if (r.do_zero) {
      drive.ZeroCurrentPosition();
      if (ECHO_COMMANDS) {
        Serial << "Setting current position as the zero point" << endl;
      }
    }
    if (r.do_idle) {
      drive.SetIdle();
      if (ECHO_COMMANDS) {
        Serial << "Setting drive to idle." << endl;
      }
    }

    //Homing trigger
    if (r.do_homing) {
      if (homing_lock==true){
        Serial.println("Homing the dog");
        start_motion=true;
      }
      if (ECHO_COMMANDS) {
        Serial << "Homing axes." << endl;
      }
    }


    if (r.new_debug) {
      print_debug_info = interpreter.LatestDebug();
    }
  }



  if (micros() - last_imu_ts >= IMU_DELAY) {
    // drive.UpdateIMU(); // Disable until we can figure out why it disrupts activation
    last_imu_ts = micros();
  }

//MOTOR CONTROL LOOP//ALL ACTUATOR COMMANDS MUST BE SENT IN THIS BLOCK
  if (micros() - last_command_ts >= CONTROL_DELAY) {
      if(start_motion==true){

        //To allow for the homing sequence to be triggered only once
        if (homing_lock==true){
          homing_lock=false;
          drive_lock_time=millis();
          drive.ExecuteHomingSequence();
        }
        

        //To amek sure that the drive only starts moving after homing is finished
        if(homing_lock==false&&(millis()-drive_lock_time)>=8000&&drive_lock==true){
          drive_lock=false;
          Serial.println("Homing finished. Starting motion.");
        }

        // auto pos = drive.GetActuatorPositions();
        // Serial.println("Post-homing positions:");
        // for (int i = 0; i < 12; i++) {
        //     Serial.print("J "); Serial.print(i);
        //     Serial.print(": "); Serial.println(pos[i]);
        // }

        // Serial.println("Motor Activated");
    
        // Smooth ramp for knees
        if (going_forward_knee) {
            theta_knee += 0.0005f;          // ramp forward slowly
            if (theta_knee >= MAX_ANGLE_knee) {
                going_forward_knee = false;
            }
        }
        else {
            theta_knee -= 0.0005f;          // ramp backward slowly
            if (theta_knee <= MIN_ANGLE_knee) {
                going_forward_knee = true;
            }
        }

        // Smooth ramp for shoulders
        if (going_forward_shoulder) {
            theta_shoulder += 0.0005f;          // ramp forward slowly
            if (theta_shoulder >= MAX_ANGLE_shoulder) {
                going_forward_shoulder = false;
            }
        }
        else {
            theta_shoulder -= 0.0005f;          // ramp backward slowly
            if (theta_shoulder <= MIN_ANGLE_shoulder) {
                going_forward_shoulder = true;
            }
        }


      //HOLD abductors only
      if (hold) {
          cmd[0] = hold_pos[0];   // abductor 1
          cmd[3] = hold_pos[3];   // abductor 2
          cmd[6] = hold_pos[6];   // abductor 3
          cmd[9] = hold_pos[9];   // abductor 4
      }
        // Knee Joints
        cmd[11] = theta_knee;             
        cmd[8] = theta_knee;
        cmd[5] = theta_knee;
        cmd[2] = theta_knee;
        //If the movement direction is (positive)forward, then the knees bend the feet downwards.
        

        // Shoulder Joints
        cmd[1] = -theta_shoulder;
        cmd[4] = -theta_shoulder;
        cmd[7] = -theta_shoulder;
        cmd[10] = -theta_shoulder;
        //In this configuration, forward direction (positive), makes the shoulders move the knee towards the ground.


        //Forward direction can be imagined as the dog jumping forward.

        
        // // Send command to motors
        // drive.SetJointPositions(cmd);
        // Run control loop
        drive.Update();



        // static uint32_t counter = 0;
        // if (++counter % 50 == 0) {   // print every 50 loops

        //     // Get robot geometry
        //     LegParameters leg_params = drive.GetLegParameters();

        //     // ===== Leg 0 ===== (Front Right)
        //     {
        //         uint8_t leg = 0;
        //         BLA::Matrix<3> q = drive.LegJointAngles(leg);
        //         BLA::Matrix<3> foot_pos = ForwardKinematics(q, leg_params, leg);

        //         Serial.print("Leg 0 (FR) foot: ");
        //         Serial.print(foot_pos(0)); Serial.print(", ");
        //         Serial.print(foot_pos(1)); Serial.print(", ");
        //         Serial.println(foot_pos(2));
        //     }

        //     // ===== Leg 1 ===== (Front Left)
        //     {
        //         uint8_t leg = 1;
        //         BLA::Matrix<3> q = drive.LegJointAngles(leg);
        //         BLA::Matrix<3> foot_pos = ForwardKinematics(q, leg_params, leg);

        //         Serial.print("Leg 1 (FL) foot: ");
        //         Serial.print(foot_pos(0)); Serial.print(", ");
        //         Serial.print(foot_pos(1)); Serial.print(", ");
        //         Serial.println(foot_pos(2));
        //     }

        //     Serial.println("--------------------");
        // }




        last_command_ts = micros();
    }
    

  if (!start_motion) {
      // Hold abductors
      // drive.SetJointPositions(hold_pos);
      drive.Update();
      last_command_ts = micros();
      return;
    }
  }

  if (print_debug_info) {
    if (micros() - last_print_ts >= options.print_delay_micros) {
      // drive.PrintStatus(options);
      // logger.AddData(drive.DebugData());
      // drive.PrintMsgPackStatus(options);
      //drive.PrintStatus(options);

    if (Serial.available() > 0) {
        char c = Serial.read();
        if (c == 's') {
            start_motion = true;
            hold = true;
            auto now = drive.GetActuatorPositions();

            hold_pos = {0};              // initialize all 12 elements to zero

            hold_pos[0] = now[0];
            hold_pos[3] = now[3];
            hold_pos[6] = now[6];
            hold_pos[9] = now[9];

            Serial.println("Starting motor motion test...");
        }
        if (c == 'x') {
            start_motion = false;
            hold = false;
            Serial.println("Stopping motor motion test...");
        }
    }

      // Serial.println(" ");
      last_print_ts = micros();
    }

    if (print_header_periodically) {
      if (millis() - last_header_ts >= options.header_delay_millis) {
        drive.PrintHeader(options);
        last_header_ts = millis();
      }
    }
  }

  
}

